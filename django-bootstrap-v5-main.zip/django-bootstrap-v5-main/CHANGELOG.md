# Changelog

## [1.0.4] - Update dependencies 2021-05-16

- importlib-metadata version dependency

## [1.0.3] - Fix small bugs 2021-05-01

- Fix inline file field display

## [1.0.2] - Fix small bugs 2021-04-08

- Fix checkbox label display

## [1.0.1] - More Bootstrap 5 adjustments 2021-03-23

- Form rendering is not adapted to v5

## [1.0.0] - Initial release 2020-12-12

- Convert from bootstrap 4 to 5
