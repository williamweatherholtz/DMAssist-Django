Welcome to django-bootstrap-v5's documentation!
===============================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   migrate
   templatetags
   settings
   templates
   widgets
   authors
   changelog
